"use client"

import { useState } from "react"
import { Heart, X, MapPin, Calendar, Users, Video, Gift } from "lucide-react"
import { Button } from "@/components/ui/button"

export default function ProfilWioletta() {
  const [currentImageIndex, setCurrentImageIndex] = useState(0)
  const [showGallery, setShowGallery] = useState(false)

  const targetUrl = "https://allgo.xyz/link/1841/57279991"

  const images = [
    "https://nakamerce.pl/wp-content/uploads/wioletta-1.jpg",
    "https://nakamerce.pl/wp-content/uploads/wioletta-2.jpg",
    "https://nakamerce.pl/wp-content/uploads/wioletta-3.jpg",
    "https://nakamerce.pl/wp-content/uploads/wioletta-4.jpg",
    "https://nakamerce.pl/wp-content/uploads/wioletta-5.jpg",
  ]

  const nextImage = () => {
    setCurrentImageIndex((prev) => (prev + 1) % images.length)
  }

  const prevImage = () => {
    setCurrentImageIndex((prev) => (prev - 1 + images.length) % images.length)
  }

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      {/* Header */}
      <header className="bg-gray-800/90 backdrop-blur-sm border-b border-purple-500/20 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-3">
              <img src="/onenightfriend-logo.png" alt="One Night Friend" className="h-8 w-auto" />
            </div>
            <nav className="hidden md:flex space-x-8">
              <a href="/" className="text-gray-300 hover:text-purple-400 transition-colors">
                Strona główna
              </a>
              <a href={targetUrl} className="text-gray-300 hover:text-purple-400 transition-colors">
                Profile
              </a>
              <a href={targetUrl} className="text-gray-300 hover:text-purple-400 transition-colors">
                Czat
              </a>
            </nav>
            <Button
              onClick={() => window.open(targetUrl, "_blank")}
              className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
            >
              Napisz do mnie
            </Button>
          </div>
        </div>
      </header>

      <div className="max-w-6xl mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Galeria zdjęć */}
          <div className="lg:col-span-2">
            <div className="relative bg-gray-800 rounded-lg overflow-hidden">
              <img
                src={`/attractive-polish-woman-wioletta.png?height=600&width=800&query=attractive-polish-woman-wioletta-${currentImageIndex + 1}`}
                alt={`Wioletta - zdjęcie ${currentImageIndex + 1}`}
                className="w-full h-96 lg:h-[600px] object-cover"
              />

              {/* Nawigacja zdjęć */}
              <button
                onClick={prevImage}
                className="absolute left-4 top-1/2 transform -translate-y-1/2 bg-black/50 hover:bg-black/70 rounded-full p-2 transition-colors"
              >
                <X className="w-6 h-6 rotate-45" />
              </button>
              <button
                onClick={nextImage}
                className="absolute right-4 top-1/2 transform -translate-y-1/2 bg-black/50 hover:bg-black/70 rounded-full p-2 transition-colors"
              >
                <X className="w-6 h-6 -rotate-45" />
              </button>

              {/* Wskaźniki zdjęć */}
              <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex space-x-2">
                {images.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentImageIndex(index)}
                    className={`w-3 h-3 rounded-full transition-colors ${
                      index === currentImageIndex ? "bg-purple-500" : "bg-white/50"
                    }`}
                  />
                ))}
              </div>

              {/* Status online */}
              <div className="absolute top-4 left-4 bg-green-500 text-white px-3 py-1 rounded-full text-sm font-semibold flex items-center space-x-1">
                <div className="w-2 h-2 bg-white rounded-full animate-pulse"></div>
                <span>Online teraz</span>
              </div>
            </div>

            {/* Miniaturki */}
            <div className="grid grid-cols-5 gap-2 mt-4">
              {images.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentImageIndex(index)}
                  className={`relative aspect-square rounded-lg overflow-hidden border-2 transition-colors ${
                    index === currentImageIndex ? "border-purple-500" : "border-gray-600"
                  }`}
                >
                  <img
                    src={`/placeholder-jjq00.png?height=100&width=100&query=attractive-polish-woman-wioletta-thumb-${index + 1}`}
                    alt={`Miniaturka ${index + 1}`}
                    className="w-full h-full object-cover"
                  />
                </button>
              ))}
            </div>
          </div>

          {/* Informacje o profilu */}
          <div className="space-y-6">
            {/* Podstawowe info */}
            <div className="bg-gray-800 rounded-lg p-6 border border-purple-500/20">
              <h1 className="text-3xl font-bold text-purple-400 mb-2">Wioletta</h1>
              <div className="space-y-3 text-gray-300">
                <div className="flex items-center space-x-2">
                  <Calendar className="w-5 h-5 text-purple-400" />
                  <span>22 lata</span>
                </div>
                <div className="flex items-center space-x-2">
                  <MapPin className="w-5 h-5 text-purple-400" />
                  <span>Warszawa, 2.1 km od Ciebie</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Users className="w-5 h-5 text-purple-400" />
                  <span>Szukam: Sponsora na studia</span>
                </div>
              </div>
            </div>

            {/* Przyciski akcji */}
            <div className="space-y-3">
              <Button
                onClick={() => window.open(targetUrl, "_blank")}
                className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 h-12 text-lg"
              >
                <Heart className="w-5 h-5 mr-2" />
                Napisz do mnie
              </Button>
              <Button
                onClick={() => window.open(targetUrl, "_blank")}
                variant="outline"
                className="w-full border-purple-500 text-purple-400 hover:bg-purple-500/10 h-12"
              >
                <Video className="w-5 h-5 mr-2" />
                Czat wideo
              </Button>
              <Button
                onClick={() => window.open(targetUrl, "_blank")}
                variant="outline"
                className="w-full border-pink-500 text-pink-400 hover:bg-pink-500/10 h-12"
              >
                <Gift className="w-5 h-5 mr-2" />
                Wyślij prezent
              </Button>
            </div>

            {/* O mnie */}
            <div className="bg-gray-800 rounded-lg p-6 border border-purple-500/20">
              <h3 className="text-xl font-semibold text-purple-400 mb-4">O mnie</h3>
              <p className="text-gray-300 leading-relaxed">
                Cześć! Jestem Wioletta, studentka psychologii w Warszawie. Szukam kogoś, kto pomoże mi sfinansować
                studia i życie w stolicy. W zamian oferuję miłe towarzystwo, wspólne wyjścia i wdzięczność. Lubię teatr,
                dobre wino i romantyczne kolacje. Jestem otwarta na różne propozycje współpracy 😘
              </p>
            </div>

            {/* Zainteresowania */}
            <div className="bg-gray-800 rounded-lg p-6 border border-purple-500/20">
              <h3 className="text-xl font-semibold text-purple-400 mb-4">Zainteresowania</h3>
              <div className="flex flex-wrap gap-2">
                {["Psychologia", "Teatr", "Wino", "Podróże", "Spa", "Shopping", "Joga", "Fotografia"].map(
                  (interest) => (
                    <span key={interest} className="bg-purple-500/20 text-purple-300 px-3 py-1 rounded-full text-sm">
                      {interest}
                    </span>
                  ),
                )}
              </div>
            </div>

            {/* Statystyki */}
            <div className="bg-gray-800 rounded-lg p-6 border border-purple-500/20">
              <h3 className="text-xl font-semibold text-purple-400 mb-4">Statystyki</h3>
              <div className="space-y-3 text-gray-300">
                <div className="flex justify-between">
                  <span>Ostatnio online:</span>
                  <span className="text-green-400">Teraz</span>
                </div>
                <div className="flex justify-between">
                  <span>Odpowiada na:</span>
                  <span className="text-purple-400">95% wiadomości</span>
                </div>
                <div className="flex justify-between">
                  <span>Czas odpowiedzi:</span>
                  <span className="text-purple-400">Kilka minut</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

"use client"

import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Users, Zap, Play, ImageIcon } from "lucide-react"
import React, { useState, useEffect } from "react"

export default function LandingPage() {
  const targetUrl = "https://allgo.xyz/link/1841/57279991"

  const [showLocationPopup, setShowLocationPopup] = useState(false)

  useEffect(() => {
    const timer = setTimeout(() => {
      setShowLocationPopup(true)
    }, 5000)

    return () => clearTimeout(timer)
  }, [])

  const getCurrentTime = () => {
    return new Date().toLocaleTimeString("pl-PL", {
      hour: "2-digit",
      minute: "2-digit",
    })
  }

  let messageTypeCounter = 0

  const addRandomMessage = () => {
    const chatMessages = document.getElementById("chat-messages")
    if (!chatMessages) return

    const messageDiv = document.createElement("div")
    messageDiv.className = "flex items-start space-x-3 opacity-0 animate-fade-in"
    messageDiv.style.animationFillMode = "forwards"

    const randomNames = ["Ania", "Kasia", "Maja", "Ola", "Zosia", "Wika", "Iza", "Natalia"]
    const randomName = randomNames[Math.floor(Math.random() * randomNames.length)]
    const randomIndex = Math.floor(Math.random() * 10) + 1

    const messageTypes = [
      [
        "Szukam sponsora na zakupy 💸 Kto pomoże?",
        "Potrzebuję kogoś hojnego na wakacje ✈️ Będę wdzięczna 😘",
        "Kto opłaci mi rachunki? Pokażę się z wdzięczności 💋",
        "Sugar daddy wanted! 💎 Umiem być miła",
        "Szukam kogoś na shopping 🛍️ Odwdzięczę się",
        "Potrzebuję wsparcia finansowego 💰 Jestem bardzo wdzięczna",
      ],
      [
        "Szukam kogoś na spotkanie w Warszawie 💕 Kto ma ochotę?",
        "Może randka w Krakowie? Jestem wolna dziś wieczorem 🌙",
        "Gdańsk - kto chce się spotkać nad morzem? 🌊",
        "Wrocław - szukam towarzysza na wieczór 🥂",
        "Poznań - może kolacja we dwoje? 🍷",
        "Katowice - kto ma ochotę na spotkanie? 😊",
        "Łódź - szukam kogoś na randkę w weekend 💖",
        "Szczecin - może pójdziemy gdzieś razem? 🌹",
        "Lublin - kto chce się spotkać na kawie? ☕",
        "Bydgoszcz - szukam towarzysza na dziś 💫",
        "Białystok - może spotkanie w centrum? 🏙️",
        "Rzeszów - kto ma ochotę na randkę? 💕",
        "Toruń - szukam kogoś miłego na wieczór 🌃",
        "Opole - może kolacja przy świecach? 🕯️",
        "Kielce - kto chce się spotkać? Jestem samotna 💔",
        "Olsztyn - szukam kogoś na mazurach 🏞️",
      ],
      [
        "Kto ma ochotę na długą rozmowę? 💬",
        "Szukam kogoś do pogadania przez całą noc 🌃",
        "Może porozmawiamy o życiu? Jestem samotna 💭",
        "Kto lubi głębokie rozmowy? 🤔",
        "Potrzebuję kogoś do wysłuchania 👂",
        "Może video call? Chcę zobaczyć twoje oczy 👀",
      ],
    ]

    const currentType = messageTypeCounter % 3
    const messages = messageTypes[currentType]
    const randomMessage = messages[Math.floor(Math.random() * messages.length)]
    messageTypeCounter++

    messageDiv.innerHTML = `
      <div class="w-8 h-8 flex-shrink-0 bg-purple-600 rounded-full flex items-center justify-center text-white text-xs font-bold">
        ${randomName[0]}
      </div>
      <div class="flex-1 min-w-0">
        <div class="flex items-center space-x-2">
          <span class="text-sm font-semibold text-purple-400">${randomName}</span>
          <span class="text-xs text-gray-500">${getCurrentTime()}</span>
        </div>
        <p class="text-sm text-gray-300 mt-1">${randomMessage}</p>
      </div>
    `

    chatMessages.appendChild(messageDiv)
    chatMessages.scrollTop = chatMessages.scrollHeight
  }

  React.useEffect(() => {
    const messageInterval = setInterval(
      () => {
        addRandomMessage()
      },
      Math.random() * 8000 + 7000,
    ) // 7-15 sekund

    return () => {
      clearInterval(messageInterval)
    }
  }, [])

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      {/* Header */}
      <header className="bg-gray-800/50 backdrop-blur-sm border-b border-purple-500/20 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <img src="/onenightfriend-logo.png" alt="One Night Friend" className="h-8 w-auto" />
          </div>

          <nav className="hidden md:flex space-x-8">
            <a href="#home" className="text-gray-300 hover:text-purple-400 transition-colors">
              Home
            </a>
            <a href="#profiles" className="text-gray-300 hover:text-purple-400 transition-colors">
              Profile na żywo
            </a>
            <a href="#chat" className="text-gray-300 hover:text-purple-400 transition-colors">
              Czat
            </a>
            <a href="#roulette" className="text-gray-300 hover:text-purple-400 transition-colors">
              Ruletka
            </a>
            <a href="#hit-or-miss" className="text-gray-300 hover:text-purple-400 transition-colors">
              Chybił-Trafił
            </a>
            <a href="#gallery" className="text-gray-300 hover:text-purple-400 transition-colors">
              Profile kobiet
            </a>
            <a href="#recent-content" className="text-gray-300 hover:text-purple-400 transition-colors">
              Najnowsze
            </a>
            <a href="#videos" className="text-gray-300 hover:text-purple-400 transition-colors">
              Filmy
            </a>
          </nav>

          <div className="flex items-center space-x-3">
            <Button
              variant="outline"
              size="sm"
              className="border-purple-500 text-purple-400 hover:bg-purple-500 hover:text-white bg-transparent"
              asChild
            >
              <a href={targetUrl}>Zaloguj się</a>
            </Button>
            <Button size="sm" className="bg-purple-600 hover:bg-purple-700" asChild>
              <a href={targetUrl}>Dołącz teraz</a>
            </Button>
          </div>
        </div>
      </header>

      {/* Live Profiles Panorama */}
      <section id="profiles" className="bg-gray-800/30 py-6 border-b border-gray-700/50">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-2xl font-bold text-purple-400">Profile na żywo</h2>
          </div>
          <div className="overflow-hidden">
            <div className="flex items-center space-x-4 animate-scroll">
              <div className="flex space-x-4 min-w-max">
                {[
                  { name: "Ania", age: 25, status: "live", viewers: 234 },
                  { name: "Kasia", age: 29, status: "live", viewers: 156 },
                  { name: "Maja", age: 23, status: "live", viewers: 89 },
                  { name: "Ola", age: 31, status: "live", viewers: 312 },
                  { name: "Zosia", age: 27, status: "live", viewers: 178 },
                  { name: "Wika", age: 26, status: "live", viewers: 203 },
                  { name: "Iza", age: 24, status: "live", viewers: 145 },
                  { name: "Natalia", age: 30, status: "live", viewers: 267 },
                ].map((user, index) => (
                  <div
                    key={index}
                    className="flex-shrink-0 relative group cursor-pointer hover:scale-105 transition-transform duration-200"
                  >
                    <a href={targetUrl} className="block">
                      <div className="relative w-32 h-32 rounded-lg overflow-hidden bg-gradient-to-br from-purple-900/50 to-pink-900/50 shadow-lg">
                        <div className="absolute inset-0 bg-gradient-to-br from-purple-600/30 via-pink-600/20 to-purple-800/40 blur-sm"></div>
                        <div className="absolute inset-0 bg-black/20"></div>

                        <div className="absolute inset-0 flex items-center justify-center">
                          <Avatar className="w-16 h-16 border-2 border-purple-400 shadow-lg">
                            <AvatarImage
                              src={`https://nakamerce.pl/wp-content/uploads/2025/08/profile-${index + 1}.jpg`}
                            />
                            <AvatarFallback className="bg-purple-600 text-white text-sm font-bold">
                              {user.name[0]}
                            </AvatarFallback>
                          </Avatar>
                        </div>

                        <div className="absolute top-2 left-2 bg-red-500 text-white text-xs px-2 py-1 rounded font-bold">
                          LIVE
                        </div>

                        <div className="absolute bottom-2 right-2 bg-black/70 text-white text-xs px-2 py-1 rounded flex items-center">
                          <Users className="w-3 h-3 mr-1" />
                          {user.viewers}
                        </div>

                        <div className="absolute bottom-2 left-2 text-white">
                          <p className="text-sm font-semibold drop-shadow-lg">{user.name}</p>
                          <p className="text-xs opacity-90 drop-shadow-lg">{user.age} lat</p>
                        </div>

                        <div className="absolute inset-0 bg-purple-600/20 opacity-0 group-hover:opacity-100 transition-opacity duration-200 flex items-center justify-center">
                          <Play className="w-8 h-8 text-white drop-shadow-lg" />
                        </div>
                      </div>
                    </a>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Profile Roulette Section */}
      <section id="roulette" className="py-16 px-4 bg-gray-900 border-b border-gray-700/50">
        <div className="container mx-auto">
          <h2 className="text-3xl font-bold text-center mb-12 text-purple-400">Ruletka Profili</h2>
          <div className="max-w-2xl mx-auto">
            {/* Filtry wyszukiwania */}
            <div className="bg-gray-800 rounded-lg p-6 mb-8 shadow-lg">
              <h3 className="text-lg font-semibold text-purple-400 mb-4">Filtry wyszukiwania</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">Miasto</label>
                  <select
                    id="city-filter"
                    className="w-full bg-gray-700 text-white px-3 py-2 rounded-lg border border-gray-600 focus:border-purple-500 focus:outline-none"
                  >
                    <option value="">Wszystkie miasta</option>
                    <option value="Warszawa">Warszawa</option>
                    <option value="Kraków">Kraków</option>
                    <option value="Gdańsk">Gdańsk</option>
                    <option value="Wrocław">Wrocław</option>
                    <option value="Poznań">Poznań</option>
                    <option value="Katowice">Katowice</option>
                    <option value="Łódź">Łódź</option>
                    <option value="Szczecin">Szczecin</option>
                    <option value="Lublin">Lublin</option>
                    <option value="Bydgoszcz">Bydgoszcz</option>
                    <option value="Białystok">Białystok</option>
                    <option value="Rzeszów">Rzeszów</option>
                    <option value="Toruń">Toruń</option>
                    <option value="Opole">Opole</option>
                    <option value="Kielce">Kielce</option>
                    <option value="Olsztyn">Olsztyn</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">Wiek</label>
                  <select
                    id="age-filter"
                    className="w-full bg-gray-700 text-white px-3 py-2 rounded-lg border border-gray-600 focus:border-purple-500 focus:outline-none"
                  >
                    <option value="">Wszystkie wieki</option>
                    <option value="18-25">18-25 lat</option>
                    <option value="26-30">26-30 lat</option>
                    <option value="31-35">31-35 lat</option>
                    <option value="36-40">36-40 lat</option>
                    <option value="41-45">41-45 lat</option>
                    <option value="46-50">46-50 lat</option>
                    <option value="51-60">51-60 lat</option>
                    <option value="61-80">61-80 lat</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">Dzieci</label>
                  <select
                    id="children-filter"
                    className="w-full bg-gray-700 text-white px-3 py-2 rounded-lg border border-gray-600 focus:border-purple-500 focus:outline-none"
                  >
                    <option value="">Bez preferencji</option>
                    <option value="ma-dzieci">Ma dzieci</option>
                    <option value="nie-ma-dzieci">Nie ma dzieci</option>
                    <option value="chce-dzieci">Chce mieć dzieci</option>
                    <option value="nie-chce-dzieci">Nie chce dzieci</option>
                  </select>
                </div>
              </div>
            </div>

            <div className="relative">
              <div className="aspect-square bg-gradient-to-br from-purple-900/50 to-pink-900/50 rounded-full overflow-hidden shadow-2xl border-4 border-purple-500/30 mx-auto mb-8">
                <div id="roulette-profile" className="w-full h-full flex items-center justify-center">
                  <div className="text-center">
                    <Avatar className="w-32 h-32 mx-auto mb-4 border-4 border-purple-400">
                      <AvatarImage
                        id="roulette-avatar"
                        src="https://nakamerce.pl/wp-content/uploads/2025/08/roulette-default.jpg"
                      />
                      <AvatarFallback className="bg-purple-600 text-white text-2xl font-bold">?</AvatarFallback>
                    </Avatar>
                    <h3 id="roulette-name" className="text-2xl font-bold text-white mb-2">
                      Kliknij "Kręć"
                    </h3>
                    <p id="roulette-age" className="text-lg text-gray-300 mb-4">
                      aby rozpocząć
                    </p>
                    <div id="roulette-info" className="text-sm text-gray-400"></div>
                  </div>
                </div>
              </div>

              <div className="text-center space-y-4">
                <Button
                  id="spin-button"
                  size="lg"
                  className="bg-purple-600 hover:bg-purple-700 text-lg px-12 py-4 rounded-full shadow-lg transform hover:scale-105 transition-all duration-200"
                  onClick={() => {
                    const allProfiles = [
                      {
                        name: "Anna",
                        age: 24,
                        city: "Warszawa",
                        info: "Szuka sponsora na zakupy",
                        children: "nie-ma-dzieci",
                      },
                      {
                        name: "Kasia",
                        age: 26,
                        city: "Kraków",
                        info: "Chce spotkać się na kolacji",
                        children: "ma-dzieci",
                      },
                      {
                        name: "Maja",
                        age: 23,
                        city: "Gdańsk",
                        info: "Szuka kogoś do rozmowy",
                        children: "nie-ma-dzieci",
                      },
                      {
                        name: "Ola",
                        age: 28,
                        city: "Wrocław",
                        info: "Potrzebuje wsparcia finansowego",
                        children: "chce-dzieci",
                      },
                      { name: "Zosia", age: 25, city: "Poznań", info: "Szuka sugar daddy", children: "nie-ma-dzieci" },
                      {
                        name: "Ania",
                        age: 27,
                        city: "Katowice",
                        info: "Chce spotkać się dziś wieczorem",
                        children: "ma-dzieci",
                      },
                      {
                        name: "Wika",
                        age: 24,
                        city: "Łódź",
                        info: "Szuka sponsora na studia",
                        children: "nie-chce-dzieci",
                      },
                      {
                        name: "Iza",
                        age: 29,
                        city: "Szczecin",
                        info: "Potrzebuje pomocy z czynszem",
                        children: "ma-dzieci",
                      },
                      { name: "Ewa", age: 32, city: "Lublin", info: "Szuka kogoś hojnego", children: "chce-dzieci" },
                      {
                        name: "Marta",
                        age: 35,
                        city: "Bydgoszcz",
                        info: "Chce spotkać się na kawie",
                        children: "ma-dzieci",
                      },
                      {
                        name: "Kinga",
                        age: 38,
                        city: "Białystok",
                        info: "Szuka sponsora na biznes",
                        children: "nie-chce-dzieci",
                      },
                      { name: "Natalia", age: 42, city: "Rzeszów", info: "Potrzebuje wsparcia", children: "ma-dzieci" },
                      { name: "Agata", age: 45, city: "Toruń", info: "Szuka kogoś dojrzałego", children: "ma-dzieci" },
                      {
                        name: "Beata",
                        age: 48,
                        city: "Opole",
                        info: "Chce spotkać się na kolacji",
                        children: "nie-chce-dzieci",
                      },
                      { name: "Dorota", age: 52, city: "Kielce", info: "Szuka towarzysza", children: "ma-dzieci" },
                      {
                        name: "Elżbieta",
                        age: 55,
                        city: "Olsztyn",
                        info: "Potrzebuje kogoś miłego",
                        children: "nie-ma-dzieci",
                      },
                      { name: "Grażyna", age: 58, city: "Warszawa", info: "Szuka sponsora", children: "ma-dzieci" },
                      {
                        name: "Halina",
                        age: 62,
                        city: "Kraków",
                        info: "Chce spotkać się",
                        children: "nie-chce-dzieci",
                      },
                      { name: "Irena", age: 65, city: "Gdańsk", info: "Szuka towarzysza", children: "ma-dzieci" },
                      {
                        name: "Janina",
                        age: 68,
                        city: "Wrocław",
                        info: "Potrzebuje wsparcia",
                        children: "nie-ma-dzieci",
                      },
                    ]

                    const cityFilter = (document.getElementById("city-filter") as HTMLSelectElement)?.value
                    const ageFilter = (document.getElementById("age-filter") as HTMLSelectElement)?.value
                    const childrenFilter = (document.getElementById("children-filter") as HTMLSelectElement)?.value

                    let filteredProfiles = allProfiles.filter((profile) => {
                      if (cityFilter && profile.city !== cityFilter) return false
                      if (ageFilter) {
                        const [minAge, maxAge] = ageFilter.split("-").map(Number)
                        if (profile.age < minAge || profile.age > maxAge) return false
                      }
                      if (childrenFilter && profile.children !== childrenFilter) return false
                      return true
                    })

                    if (filteredProfiles.length === 0) {
                      filteredProfiles = allProfiles
                    }

                    const spinButton = document.getElementById("spin-button")
                    const rouletteProfile = document.getElementById("roulette-profile")
                    const rouletteAvatar = document.getElementById("roulette-avatar")
                    const rouletteName = document.getElementById("roulette-name")
                    const rouletteAge = document.getElementById("roulette-age")
                    const rouletteInfo = document.getElementById("roulette-info")
                    const contactButton = document.getElementById("contact-button")

                    if (
                      spinButton &&
                      rouletteProfile &&
                      rouletteAvatar &&
                      rouletteName &&
                      rouletteAge &&
                      rouletteInfo &&
                      contactButton
                    ) {
                      spinButton.textContent = "Kręcę..."
                      spinButton.disabled = true
                      rouletteProfile.style.transform = "rotate(1800deg)"
                      rouletteProfile.style.transition = "transform 2s ease-out"

                      setTimeout(() => {
                        const randomProfile = filteredProfiles[Math.floor(Math.random() * filteredProfiles.length)]
                        const profileIndex = Math.floor(Math.random() * 10) + 1

                        const childrenText =
                          {
                            "ma-dzieci": "Ma dzieci",
                            "nie-ma-dzieci": "Nie ma dzieci",
                            "chce-dzieci": "Chce mieć dzieci",
                            "nie-chce-dzieci": "Nie chce dzieci",
                          }[randomProfile.children] || ""

                        rouletteAvatar.src = `/abstract-portrait.png?height=128&width=128&query=attractive woman ${randomProfile.name} ${profileIndex}`
                        rouletteName.textContent = randomProfile.name
                        rouletteAge.textContent = `${randomProfile.age} lat, ${randomProfile.city}`
                        rouletteInfo.innerHTML = `
                          <div class="space-y-1">
                            <p>${randomProfile.info}</p>
                            <p class="text-xs text-purple-300">${childrenText}</p>
                          </div>
                        `

                        spinButton.textContent = "Kręć ponownie"
                        spinButton.disabled = false
                        contactButton.style.display = "block"

                        rouletteProfile.style.transform = "rotate(0deg)"
                        rouletteProfile.style.transition = "none"
                      }, 2000)
                    }
                  }}
                >
                  🎰 Kręć ruletką
                </Button>

                <Button
                  id="contact-button"
                  size="lg"
                  className="bg-pink-600 hover:bg-pink-700 text-lg px-8 py-3 rounded-full shadow-lg hidden"
                  asChild
                  style={{ display: "none" }}
                >
                  <a href={targetUrl}>💕 Skontaktuj się</a>
                </Button>
              </div>
            </div>

            <div className="text-center mt-8">
              <p className="text-gray-400 text-sm mb-4">Kliknij "Kręć ruletką" aby losowo wybrać profil do poznania!</p>
              <div className="flex justify-center space-x-4 text-xs text-gray-500">
                <span>🎯 Losowy wybór</span>
                <span>💫 Nowe profile</span>
                <span>🔥 Gorące kontakty</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Hit or Miss Section */}
      <section id="hit-or-miss" className="py-16 px-4 bg-gray-800/50 border-b border-gray-700/50">
        <div className="container mx-auto">
          <h2 className="text-3xl font-bold text-center mb-12 text-purple-400">Chybił - Trafił</h2>

          <div className="max-w-md mx-auto mb-8">
            <div className="bg-gray-800/70 rounded-lg p-4 border border-purple-500/30">
              <label className="block text-sm font-medium text-purple-400 mb-2">Odległość od Ciebie</label>
              <select
                id="distance-filter"
                className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-purple-500"
                onChange={() => {
                  const selectedDistance = (document.getElementById("distance-filter") as HTMLSelectElement).value
                  console.log("[v0] Wybrana odległość:", selectedDistance)
                }}
              >
                <option value="all">Cała Polska</option>
                <option value="1">Do 1 km</option>
                <option value="5">Do 5 km</option>
                <option value="10">Do 10 km</option>
                <option value="20">Do 20 km</option>
                <option value="50">Do 50 km</option>
                <option value="100">Do 100 km</option>
                <option value="180">Do 180 km</option>
              </select>
              <p className="text-xs text-gray-400 mt-1">Znajdź kogoś w pobliżu lub rozszerz zasięg</p>
            </div>
          </div>

          <div className="max-w-md mx-auto">
            <div className="relative">
              {/* Karta profilu */}
              <div
                id="hit-miss-card"
                className="bg-gradient-to-br from-purple-900/50 to-pink-900/50 rounded-2xl overflow-hidden shadow-2xl border border-purple-500/30 aspect-[3/4] relative"
              >
                <img
                  id="hit-miss-photo"
                  src="/attractive-young-woman-profile.png"
                  alt="Profil do oceny"
                  className="w-full h-full object-cover"
                />

                {/* Gradient overlay na dole */}
                <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent p-6">
                  <h3 id="hit-miss-name" className="text-2xl font-bold text-white mb-1">
                    Anna
                  </h3>
                  <p id="hit-miss-age" className="text-lg text-gray-300 mb-2">
                    24 lata, Warszawa
                  </p>
                  <p id="hit-miss-info" className="text-sm text-gray-400">
                    Szuka kogoś na spotkanie
                  </p>
                </div>

                {/* Licznik profili */}
                <div className="absolute top-4 right-4 bg-black/70 text-white text-sm px-3 py-1 rounded-full">
                  <span id="profile-counter">1</span> / 20
                </div>
              </div>

              {/* Przyciski akcji */}
              <div className="flex justify-center space-x-8 mt-8">
                {/* Przycisk X (Nie) */}
                <button
                  id="reject-button"
                  className="w-16 h-16 bg-red-500 hover:bg-red-600 rounded-full flex items-center justify-center shadow-lg transform hover:scale-110 transition-all duration-200 active:scale-95"
                  onClick={() => {
                    const profiles = [
                      {
                        name: "Anna",
                        age: 24,
                        city: "Warszawa",
                        info: "Szuka kogoś na spotkanie",
                        photo: "attractive-woman-1",
                      },
                      {
                        name: "Kasia",
                        age: 26,
                        city: "Kraków",
                        info: "Potrzebuje sponsora",
                        photo: "attractive-woman-2",
                      },
                      {
                        name: "Maja",
                        age: 23,
                        city: "Gdańsk",
                        info: "Chce się spotkać dziś",
                        photo: "attractive-woman-3",
                      },
                      { name: "Ola", age: 28, city: "Wrocław", info: "Szuka sugar daddy", photo: "attractive-woman-4" },
                      {
                        name: "Zosia",
                        age: 25,
                        city: "Poznań",
                        info: "Potrzebuje wsparcia",
                        photo: "attractive-woman-5",
                      },
                      { name: "Ania", age: 27, city: "Katowice", info: "Chce na kolację", photo: "attractive-woman-6" },
                      {
                        name: "Wika",
                        age: 24,
                        city: "Łódź",
                        info: "Szuka sponsora na studia",
                        photo: "attractive-woman-7",
                      },
                      {
                        name: "Iza",
                        age: 29,
                        city: "Szczecin",
                        info: "Potrzebuje pomocy",
                        photo: "attractive-woman-8",
                      },
                      {
                        name: "Ewa",
                        age: 26,
                        city: "Lublin",
                        info: "Szuka kogoś hojnego",
                        photo: "attractive-woman-9",
                      },
                      { name: "Marta", age: 25, city: "Bydgoszcz", info: "Chce na kawę", photo: "attractive-woman-10" },
                      {
                        name: "Kinga",
                        age: 27,
                        city: "Białystok",
                        info: "Szuka sponsora",
                        photo: "attractive-woman-11",
                      },
                      {
                        name: "Natalia",
                        age: 24,
                        city: "Rzeszów",
                        info: "Potrzebuje wsparcia",
                        photo: "attractive-woman-12",
                      },
                      {
                        name: "Agata",
                        age: 28,
                        city: "Toruń",
                        info: "Szuka kogoś dojrzałego",
                        photo: "attractive-woman-13",
                      },
                      { name: "Beata", age: 26, city: "Opole", info: "Chce się spotkać", photo: "attractive-woman-14" },
                      {
                        name: "Dorota",
                        age: 25,
                        city: "Kielce",
                        info: "Szuka towarzysza",
                        photo: "attractive-woman-15",
                      },
                      {
                        name: "Elżbieta",
                        age: 27,
                        city: "Olsztyn",
                        info: "Potrzebuje kogoś miłego",
                        photo: "attractive-woman-16",
                      },
                      {
                        name: "Grażyna",
                        age: 24,
                        city: "Warszawa",
                        info: "Szuka sponsora",
                        photo: "attractive-woman-17",
                      },
                      {
                        name: "Halina",
                        age: 26,
                        city: "Kraków",
                        info: "Chce się spotkać",
                        photo: "attractive-woman-18",
                      },
                      {
                        name: "Irena",
                        age: 25,
                        city: "Gdańsk",
                        info: "Szuka towarzysza",
                        photo: "attractive-woman-19",
                      },
                      {
                        name: "Janina",
                        age: 28,
                        city: "Wrocław",
                        info: "Potrzebuje wsparcia",
                        photo: "attractive-woman-20",
                      },
                    ]

                    let currentIndex =
                      Number.parseInt(document.getElementById("profile-counter")?.textContent || "1") - 1

                    // Animacja odrzucenia (przesunięcie w lewo)
                    const card = document.getElementById("hit-miss-card")
                    if (card) {
                      card.style.transform = "translateX(-100%) rotate(-30deg)"
                      card.style.opacity = "0"

                      setTimeout(() => {
                        currentIndex = (currentIndex + 1) % profiles.length
                        const profile = profiles[currentIndex]

                        document.getElementById("hit-miss-photo")!.src =
                          `/placeholder.svg?height=600&width=400&query=${profile.photo}`
                        document.getElementById("hit-miss-name")!.textContent = profile.name
                        document.getElementById("hit-miss-age")!.textContent = `${profile.age} lata, ${profile.city}`
                        document.getElementById("hit-miss-info")!.textContent = profile.info
                        document.getElementById("profile-counter")!.textContent = (currentIndex + 1).toString()

                        card.style.transform = "translateX(0) rotate(0deg)"
                        card.style.opacity = "1"
                        card.style.transition = "all 0.3s ease-out"
                      }, 300)
                    }
                  }}
                >
                  <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>

                {/* Przycisk Serce (Tak) */}
                <button
                  id="like-button"
                  className="w-16 h-16 bg-pink-500 hover:bg-pink-600 rounded-full flex items-center justify-center shadow-lg transform hover:scale-110 transition-all duration-200 active:scale-95"
                  onClick={() => {
                    const profiles = [
                      {
                        name: "Anna",
                        age: 24,
                        city: "Warszawa",
                        info: "Szuka kogoś na spotkanie",
                        photo: "attractive-woman-1",
                      },
                      {
                        name: "Kasia",
                        age: 26,
                        city: "Kraków",
                        info: "Potrzebuje sponsora",
                        photo: "attractive-woman-2",
                      },
                      {
                        name: "Maja",
                        age: 23,
                        city: "Gdańsk",
                        info: "Chce się spotkać dziś",
                        photo: "attractive-woman-3",
                      },
                      { name: "Ola", age: 28, city: "Wrocław", info: "Szuka sugar daddy", photo: "attractive-woman-4" },
                      {
                        name: "Zosia",
                        age: 25,
                        city: "Poznań",
                        info: "Potrzebuje wsparcia",
                        photo: "attractive-woman-5",
                      },
                      { name: "Ania", age: 27, city: "Katowice", info: "Chce na kolację", photo: "attractive-woman-6" },
                      {
                        name: "Wika",
                        age: 24,
                        city: "Łódź",
                        info: "Szuka sponsora na studia",
                        photo: "attractive-woman-7",
                      },
                      {
                        name: "Iza",
                        age: 29,
                        city: "Szczecin",
                        info: "Potrzebuje pomocy",
                        photo: "attractive-woman-8",
                      },
                      {
                        name: "Ewa",
                        age: 26,
                        city: "Lublin",
                        info: "Szuka kogoś hojnego",
                        photo: "attractive-woman-9",
                      },
                      { name: "Marta", age: 25, city: "Bydgoszcz", info: "Chce na kawę", photo: "attractive-woman-10" },
                      {
                        name: "Kinga",
                        age: 27,
                        city: "Białystok",
                        info: "Szuka sponsora",
                        photo: "attractive-woman-11",
                      },
                      {
                        name: "Natalia",
                        age: 24,
                        city: "Rzeszów",
                        info: "Potrzebuje wsparcia",
                        photo: "attractive-woman-12",
                      },
                      {
                        name: "Agata",
                        age: 28,
                        city: "Toruń",
                        info: "Szuka kogoś dojrzałego",
                        photo: "attractive-woman-13",
                      },
                      { name: "Beata", age: 26, city: "Opole", info: "Chce się spotkać", photo: "attractive-woman-14" },
                      {
                        name: "Dorota",
                        age: 25,
                        city: "Kielce",
                        info: "Szuka towarzysza",
                        photo: "attractive-woman-15",
                      },
                      {
                        name: "Elżbieta",
                        age: 27,
                        city: "Olsztyn",
                        info: "Potrzebuje kogoś miłego",
                        photo: "attractive-woman-16",
                      },
                      {
                        name: "Grażyna",
                        age: 24,
                        city: "Warszawa",
                        info: "Szuka sponsora",
                        photo: "attractive-woman-17",
                      },
                      {
                        name: "Halina",
                        age: 26,
                        city: "Kraków",
                        info: "Chce się spotkać",
                        photo: "attractive-woman-18",
                      },
                      {
                        name: "Irena",
                        age: 25,
                        city: "Gdańsk",
                        info: "Szuka towarzysza",
                        photo: "attractive-woman-19",
                      },
                      {
                        name: "Janina",
                        age: 28,
                        city: "Wrocław",
                        info: "Potrzebuje wsparcia",
                        photo: "attractive-woman-20",
                      },
                    ]

                    let currentIndex =
                      Number.parseInt(document.getElementById("profile-counter")?.textContent || "1") - 1

                    // Pokazanie popup "To match!"
                    const matchPopup = document.createElement("div")
                    matchPopup.className = "fixed inset-0 bg-black/80 flex items-center justify-center z-50"
                    matchPopup.innerHTML = `
                      <div class="bg-gradient-to-br from-pink-500 to-purple-600 p-8 rounded-2xl text-center max-w-sm mx-4 animate-bounce">
                        <div class="text-6xl mb-4">💕</div>
                        <h3 class="text-2xl font-bold text-white mb-2">To match!</h3>
                        <p class="text-pink-100 mb-4">Polubiliście się nawzajem!</p>
                        <button onclick="this.parentElement.parentElement.remove(); window.open('${targetUrl}', '_blank')" 
                                class="bg-white text-pink-600 px-6 py-2 rounded-full font-semibold hover:bg-pink-50 transition-colors">
                          Napisz wiadomość
                        </button>
                      </div>
                    `
                    document.body.appendChild(matchPopup)

                    // Usunięcie popup po 3 sekundach
                    setTimeout(() => {
                      if (matchPopup.parentElement) {
                        matchPopup.remove()
                      }
                    }, 3000)

                    // Animacja polubienia (przesunięcie w prawo)
                    const card = document.getElementById("hit-miss-card")
                    if (card) {
                      card.style.transform = "translateX(100%) rotate(30deg)"
                      card.style.opacity = "0"

                      setTimeout(() => {
                        currentIndex = (currentIndex + 1) % profiles.length
                        const profile = profiles[currentIndex]

                        document.getElementById("hit-miss-photo")!.src =
                          `/placeholder.svg?height=600&width=400&query=${profile.photo}`
                        document.getElementById("hit-miss-name")!.textContent = profile.name
                        document.getElementById("hit-miss-age")!.textContent = `${profile.age} lata, ${profile.city}`
                        document.getElementById("hit-miss-info")!.textContent = profile.info
                        document.getElementById("profile-counter")!.textContent = (currentIndex + 1).toString()

                        card.style.transform = "translateX(0) rotate(0deg)"
                        card.style.opacity = "1"
                        card.style.transition = "all 0.3s ease-out"
                      }, 300)
                    }
                  }}
                >
                  <svg className="w-8 h-8 text-white" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z" />
                  </svg>
                </button>
              </div>

              {/* Instrukcje */}
              <div className="text-center mt-6">
                <p className="text-gray-400 text-sm mb-2">Przesuń lub kliknij aby ocenić profil</p>
                <div className="flex justify-center space-x-6 text-xs text-gray-500">
                  <span className="flex items-center">
                    <svg className="w-4 h-4 text-red-400 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                    </svg>
                    Nie podoba mi się
                  </span>
                  <span className="flex items-center">
                    <svg className="w-4 h-4 text-pink-400 mr-1" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z" />
                    </svg>
                    Podoba mi się
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Hero Section */}
      <section id="home" className="relative py-20 px-4 bg-gradient-to-br from-gray-900 via-purple-900/20 to-gray-900">
        <div className="container mx-auto text-center">
          <h1 className="text-5xl md:text-6xl font-bold mb-6">
            Znajdź swoją
            <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-400">
              drugą połówkę
            </span>
          </h1>
          <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
            Poznawaj ludzi w czasie rzeczywistym, oglądaj live streamy i znajdź idealnego partnera w naszej
            społeczności.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="bg-purple-600 hover:bg-purple-700 text-lg px-8 py-6" asChild>
              <a href={targetUrl}>
                <Play className="w-5 h-5 mr-2" />
                Rozpocznij streaming
              </a>
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="text-lg px-8 py-6 border-purple-500 text-purple-400 hover:bg-purple-500 hover:text-white bg-transparent"
              asChild
            >
              <a href={targetUrl}>
                <Users className="w-5 h-5 mr-2" />
                Przeglądaj profile
              </a>
            </Button>
          </div>
        </div>
      </section>

      {/* Chat Section */}
      <section id="chat" className="bg-gray-800 py-16 px-4 border-b border-gray-700/50">
        <div className="container mx-auto">
          <h2 className="text-3xl font-bold text-center mb-12 text-purple-400">Czat w czasie rzeczywistym</h2>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="bg-gray-900 rounded-lg p-6 shadow-lg">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-xl font-semibold text-purple-400">Czat główny</h3>
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                  <span className="text-sm text-gray-300">234 online</span>
                </div>
              </div>

              <div className="h-80 overflow-y-auto bg-gray-800 rounded-lg p-4 mb-4 space-y-3">
                <div className="chat-messages" id="chat-messages">
                  {[
                    { name: "Ania", message: "Szukam sponsora na zakupy 💸 Kto pomoże?", avatar: "A", index: 1 },
                    {
                      name: "Kasia",
                      message: "Potrzebuję kogoś hojnego na wakacje ✈️ Będę wdzięczna 😘",
                      avatar: "K",
                      index: 2,
                    },
                    {
                      name: "Maja",
                      message: "Kto opłaci mi rachunki? Pokażę się z wdzięczności 💋",
                      avatar: "M",
                      index: 3,
                    },
                    { name: "Ola", message: "Sugar daddy wanted! 💎 Umiem być miła", avatar: "O", index: 4 },
                    { name: "Zosia", message: "Szukam kogoś na shopping 🛍️ Odwdzięczę się", avatar: "Z", index: 5 },
                    {
                      name: "Wika",
                      message: "Potrzebuję wsparcia finansowego 💰 Jestem bardzo wdzięczna",
                      avatar: "W",
                      index: 6,
                    },
                    { name: "Iza", message: "Kto pomoże z czynszem? 🏠 Pokażę co potrafię", avatar: "I", index: 7 },
                    {
                      name: "Natalia",
                      message: "Szukam sponsora na studia 📚 Będę bardzo miła w zamian",
                      avatar: "N",
                      index: 8,
                    },
                  ].map((msg, index) => (
                    <div
                      key={index}
                      className="flex items-start space-x-3 opacity-0 animate-fade-in"
                      style={{
                        animationDelay: `${index * 0.3}s`,
                        animationFillMode: "forwards",
                      }}
                    >
                      <Avatar className="w-8 h-8 flex-shrink-0">
                        <AvatarImage src={`https://nakamerce.pl/wp-content/uploads/2025/08/chat-${msg.index}.jpg`} />
                        <AvatarFallback className="bg-purple-600 text-white text-xs">{msg.avatar}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center space-x-2">
                          <span className="text-sm font-semibold text-purple-400">{msg.name}</span>
                          <span className="text-xs text-gray-500">{getCurrentTime()}</span>
                        </div>
                        <p className="text-sm text-gray-300 mt-1">{msg.message}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="flex space-x-2">
                <input
                  type="text"
                  placeholder="Napisz wiadomość..."
                  className="flex-1 bg-gray-700 text-white px-4 py-2 rounded-lg border border-gray-600 focus:border-purple-500 focus:outline-none"
                />
                <Button className="bg-purple-600 hover:bg-purple-700 px-6" asChild>
                  <a href={targetUrl}>Wyślij</a>
                </Button>
              </div>
            </div>

            {/* Aktywne użytkowniczki */}
            <div className="bg-gray-900 rounded-lg p-6 shadow-lg">
              <h3 className="text-xl font-semibold text-purple-400 mb-4">Aktywne użytkowniczki</h3>
              <div className="space-y-3">
                {[
                  { name: "Ania", status: "online", lastSeen: "teraz", index: 1 },
                  { name: "Kasia", status: "online", lastSeen: "1 min temu", index: 2 },
                  { name: "Maja", status: "online", lastSeen: "teraz", index: 3 },
                  { name: "Ola", status: "away", lastSeen: "5 min temu", index: 4 },
                  { name: "Zosia", status: "online", lastSeen: "teraz", index: 5 },
                  { name: "Wika", status: "online", lastSeen: "2 min temu", index: 6 },
                ].map((user, index) => (
                  <div
                    key={index}
                    className="flex items-center justify-between p-3 bg-gray-800 rounded-lg hover:bg-gray-700 transition-colors"
                  >
                    <div className="flex items-center space-x-3">
                      <div className="relative">
                        <Avatar className="w-10 h-10">
                          <AvatarImage
                            src={`/abstract-portrait.png?height=40&width=40&query=woman ${user.name} active ${user.index}`}
                          />
                          <AvatarFallback className="bg-purple-600 text-white text-sm">{user.name[0]}</AvatarFallback>
                        </Avatar>
                        <div
                          className={`absolute -bottom-1 -right-1 w-3 h-3 rounded-full border-2 border-gray-800 ${
                            user.status === "online" ? "bg-green-500" : "bg-yellow-500"
                          }`}
                        ></div>
                      </div>
                      <div>
                        <p className="text-sm font-semibold text-white">{user.name}</p>
                        <p className="text-xs text-gray-400">{user.lastSeen}</p>
                      </div>
                    </div>
                    <Button size="sm" className="bg-purple-600 hover:bg-purple-700 text-xs" asChild>
                      <a href={targetUrl}>Napisz</a>
                    </Button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Gallery Section - Changed to Female Profiles */}
      <section id="gallery" className="py-16 px-4 bg-gray-800 border-b border-gray-700/50">
        <div className="container mx-auto">
          <div className="flex items-center justify-between mb-12">
            <h2 className="text-3xl font-bold text-purple-400">Profile kobiet</h2>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {[
              { name: "Anna", age: 24 },
              { name: "Kasia", age: 26 },
              { name: "Maja", age: 23 },
              { name: "Ola", age: 28 },
              { name: "Zosia", age: 25 },
              { name: "Ania", age: 27 },
              { name: "Wika", age: 24 },
              { name: "Iza", age: 29 },
              { name: "Ewa", age: 26 },
              { name: "Marta", age: 25 },
              { name: "Kinga", age: 27 },
              { name: "Natalia", age: 24 },
            ].map((user, index) => (
              <div key={index} className="relative group">
                <div className="aspect-square bg-gradient-to-br from-purple-900/50 to-pink-900/50 rounded-lg overflow-hidden shadow-md hover:shadow-lg transition-shadow">
                  <img
                    src={`/abstract-portrait.png?height=200&width=200&query=attractive woman ${user.name}`}
                    alt={`${user.name}, ${user.age} lat`}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors duration-300"></div>
                </div>
                <div className="text-center mt-2">
                  <p className="text-sm font-semibold text-white">{user.name}</p>
                </div>
                <div className="text-center mb-2">
                  <p className="text-sm text-gray-300">{user.age} lat</p>
                </div>
                <Button className="w-full bg-purple-600 hover:bg-purple-700 text-sm py-2" asChild>
                  <a href={targetUrl}>Poznaj</a>
                </Button>
              </div>
            ))}
          </div>
          <div className="text-center mt-8">
            <Button className="bg-purple-600 hover:bg-purple-700" asChild>
              <a href={targetUrl}>Zobacz więcej profili</a>
            </Button>
          </div>
        </div>
      </section>

      {/* Recent User Content Section */}
      <section id="recent-content" className="py-16 px-4 bg-gray-900 border-b border-gray-700/50">
        <div className="container mx-auto">
          <h2 className="text-3xl font-bold text-center mb-12 text-purple-400">
            Najnowsze zdjęcia i filmy użytkowników
          </h2>

          {/* Najnowsze zdjęcia */}
          <div className="mb-12">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-2xl font-semibold text-purple-300">📸 Zdjęcia dodane niedawno - Sekcja 18+</h3>
              <span className="text-sm text-gray-400">Ostatnie 24h</span>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
              {[
                { name: "Ania", time: "5 min temu", likes: 23 },
                { name: "Kasia", time: "12 min temu", likes: 45 },
                { name: "Maja", time: "18 min temu", likes: 31 },
                { name: "Ola", time: "25 min temu", likes: 67 },
                { name: "Zosia", time: "32 min temu", likes: 19 },
                { name: "Wika", time: "41 min temu", likes: 52 },
                { name: "Iza", time: "1h temu", likes: 38 },
                { name: "Natalia", time: "1h temu", likes: 74 },
                { name: "Ewa", time: "2h temu", likes: 29 },
                { name: "Marta", time: "2h temu", likes: 56 },
                { name: "Kinga", time: "3h temu", likes: 41 },
                { name: "Agata", time: "4h temu", likes: 33 },
              ].map((photo, index) => (
                <div key={index} className="relative group cursor-pointer">
                  <a href={targetUrl} className="block">
                    <div className="aspect-square bg-gradient-to-br from-purple-900/50 to-pink-900/50 rounded-lg overflow-hidden shadow-md hover:shadow-lg transition-all duration-300 hover:scale-105 relative">
                      <img
                        src={`https://nakamerce.pl/wp-content/uploads/2025/08/recent-photo-${index + 1}.jpg`}
                        alt={`Nowe zdjęcie od ${photo.name}`}
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                      />

                      <div className="absolute inset-0 bg-black/60 backdrop-blur-md flex items-center justify-center">
                        <div className="text-center p-3">
                          <div className="w-12 h-12 bg-red-500/80 rounded-full flex items-center justify-center mx-auto mb-2">
                            <span className="text-white text-sm font-bold">18+</span>
                          </div>
                          <p className="text-white text-xs font-semibold mb-1">Treść dla dorosłych</p>
                          <p className="text-gray-300 text-xs mb-2">Musisz być zalogowany aby obejrzeć to zdjęcie</p>
                          <div className="bg-purple-600 hover:bg-purple-700 text-white text-xs px-2 py-1 rounded transition-colors">
                            Zaloguj się
                          </div>
                        </div>
                      </div>

                      {/* Overlay z informacjami */}
                      <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-3">
                        <p className="text-white text-sm font-semibold">{photo.name}</p>
                        <p className="text-gray-300 text-xs">{photo.time}</p>
                      </div>

                      {/* Liczba polubień */}
                      <div className="absolute top-2 right-2 bg-black/70 text-white text-xs px-2 py-1 rounded-full flex items-center">
                        <span className="text-red-400 mr-1">❤️</span>
                        {photo.likes}
                      </div>

                      {/* Badge "NOWE" */}
                      <div className="absolute top-2 left-2 bg-green-500 text-white text-xs px-2 py-1 rounded font-bold">
                        NOWE
                      </div>
                    </div>
                  </a>
                </div>
              ))}
            </div>

            <div className="text-center mt-6">
              <Button className="bg-purple-600 hover:bg-purple-700" asChild>
                <a href={targetUrl}>Zobacz wszystkie zdjęcia</a>
              </Button>
            </div>
          </div>

          {/* Najnowsze filmy */}
          <div>
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-2xl font-semibold text-purple-300">🎥 Filmy dodane niedawno</h3>
              <span className="text-sm text-gray-400">Ostatnie 24h</span>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {[
                { name: "Ania", title: "Mój wieczorny look", time: "15 min temu", views: 156, duration: "0:45" },
                { name: "Kasia", title: "Taniec w sypialni", time: "28 min temu", views: 289, duration: "1:12" },
                { name: "Maja", title: "Pokaz mody", time: "45 min temu", views: 203, duration: "0:38" },
                { name: "Ola", title: "Gorący czat", time: "1h temu", views: 412, duration: "2:15" },
                { name: "Zosia", title: "Makijaż na randkę", time: "1h temu", views: 178, duration: "1:03" },
                { name: "Wika", title: "Fitness w domu", time: "2h temu", views: 234, duration: "1:28" },
                { name: "Iza", title: "Nocne zwierzenia", time: "2h temu", views: 345, duration: "3:22" },
                { name: "Natalia", title: "Prywatny pokaz", time: "3h temu", views: 567, duration: "1:45" },
              ].map((video, index) => (
                <div key={index} className="relative group cursor-pointer">
                  <a href={targetUrl} className="block">
                    <div className="aspect-video bg-gradient-to-br from-purple-900/50 to-pink-900/50 rounded-lg overflow-hidden shadow-md hover:shadow-lg transition-all duration-300 hover:scale-105 relative">
                      <img
                        src={`https://nakamerce.pl/wp-content/uploads/2025/08/video-thumb-${index + 1}.jpg`}
                        alt={video.title}
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                      />

                      <div className="absolute inset-0 bg-black/60 backdrop-blur-md flex items-center justify-center">
                        <div className="text-center p-4">
                          <div className="w-16 h-16 bg-red-500/80 rounded-full flex items-center justify-center mx-auto mb-3">
                            <span className="text-white text-2xl font-bold">18+</span>
                          </div>
                          <p className="text-white text-sm font-semibold mb-2">Treść dla dorosłych</p>
                          <p className="text-gray-300 text-xs mb-3">Musisz być zalogowany aby obejrzeć ten film</p>
                          <div className="bg-purple-600 hover:bg-purple-700 text-white text-xs px-3 py-1 rounded transition-colors">
                            Zaloguj się
                          </div>
                        </div>
                      </div>

                      {/* Video info */}
                      <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-3">
                        <p className="text-white text-sm font-semibold truncate">{video.title}</p>
                        <p className="text-gray-300 text-xs">
                          od {video.name} • {video.time}
                        </p>
                      </div>

                      {/* Duration */}
                      <div className="absolute bottom-3 right-3 bg-black/70 text-white text-xs px-2 py-1 rounded">
                        {video.duration}
                      </div>

                      {/* Views */}
                      <div className="absolute top-2 right-2 bg-black/70 text-white text-xs px-2 py-1 rounded flex items-center">
                        <span className="mr-1">👁️</span>
                        {video.views}
                      </div>

                      {/* Badge "NOWE" */}
                      <div className="absolute top-2 left-2 bg-red-500 text-white text-xs px-2 py-1 rounded font-bold">
                        NOWE
                      </div>
                    </div>
                  </a>
                </div>
              ))}
            </div>
            <div className="text-center mt-6">
              <Button className="bg-purple-600 hover:bg-purple-700" asChild>
                <a href={targetUrl}>Zobacz wszystkie filmy</a>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Video Gallery */}
      <section id="videos" className="py-16 px-4 bg-gray-800 border-b border-gray-700/50">
        <div className="container mx-auto">
          <div className="flex items-center justify-between mb-12">
            <h2 className="text-3xl font-bold text-purple-400">Live Videos</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { title: "Wieczorny czat", user: "Ania" },
              { title: "Randkowe porady", user: "Kasia" },
              { title: "Nocne rozmowy", user: "Maja" },
              { title: "Flirt na żywo", user: "Ola" },
            ].map((video, index) => (
              <div key={index} className="relative group cursor-pointer">
                <a href={targetUrl} className="block">
                  <div className="aspect-video bg-gradient-to-br from-purple-900/50 to-pink-900/50 rounded-lg overflow-hidden shadow-md hover:shadow-lg transition-shadow relative">
                    <div className="absolute inset-0 bg-gradient-to-br from-purple-600/40 via-pink-600/30 to-purple-800/50 video-blur"></div>
                    <div className="absolute inset-0 bg-black/30"></div>

                    <div className="absolute inset-0 flex items-center justify-center">
                      <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center backdrop-blur-sm border border-white/30">
                        <Play className="w-8 h-8 text-white ml-1" />
                      </div>
                    </div>

                    <div className="absolute bottom-3 left-3 text-white">
                      <p className="text-sm font-semibold drop-shadow-lg">{video.title}</p>
                      <p className="text-xs opacity-90 drop-shadow-lg">z {video.user}</p>
                    </div>

                    <div className="absolute top-3 left-3 bg-red-500 text-white text-xs px-2 py-1 rounded font-bold">
                      LIVE
                    </div>
                  </div>
                </a>
              </div>
            ))}
          </div>
          <div className="text-center mt-8">
            <Button className="bg-purple-600 hover:bg-purple-700" asChild>
              <a href={targetUrl}>Zobacz wszystkie filmy</a>
            </Button>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-16 px-4 bg-gray-800 border-b border-gray-700/50">
        <div className="container mx-auto">
          <h2 className="text-3xl font-bold text-center mb-12 text-purple-400">Dlaczego One Night Friend?</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center bg-gray-900 p-8 rounded-lg shadow-md">
              <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Zap className="w-8 h-8 text-purple-400" />
              </div>
              <h3 className="text-xl font-semibold mb-3 text-purple-400">Szybkie połączenia</h3>
              <p className="text-gray-300">
                Poznawaj ludzi natychmiast przez live chaty i dzielenie się zdjęciami w czasie rzeczywistym.
              </p>
              <Button className="mt-4 bg-purple-600 hover:bg-purple-700" asChild>
                <a href={targetUrl}>Wypróbuj teraz</a>
              </Button>
            </div>
            <div className="text-center bg-gray-900 p-8 rounded-lg shadow-md">
              <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="w-8 h-8 text-purple-400" />
              </div>
              <h3 className="text-xl font-semibold mb-3 text-purple-400">Aktywna społeczność</h3>
              <p className="text-gray-300">
                Dołącz do tysięcy aktywnych użytkowników szukających przygód i nowych znajomości.
              </p>
              <Button className="mt-4 bg-purple-600 hover:bg-purple-700" asChild>
                <a href={targetUrl}>Dołącz do nas</a>
              </Button>
            </div>
            <div className="text-center bg-gray-900 p-8 rounded-lg shadow-md">
              <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <ImageIcon className="w-8 h-8 text-purple-400" />
              </div>
              <h3 className="text-xl font-semibold mb-3 text-purple-400">Łatwe dzielenie się</h3>
              <p className="text-gray-300">
                Dodawaj i edytuj swoje zdjęcia jednym kliknięciem. Pokaż się z najlepszej strony.
              </p>
              <Button className="mt-4 bg-purple-600 hover:bg-purple-700" asChild>
                <a href={targetUrl}>Dodaj zdjęcia</a>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 bg-purple-600 text-white">
        <div className="container mx-auto text-center">
          <h2 className="text-4xl font-bold mb-6">Gotowy na nową przygodę?</h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto opacity-90">
            Dołącz do One Night Friend już dziś i znajdź kogoś wyjątkowego w naszej społeczności!
          </p>
          <Button size="lg" className="bg-white text-purple-600 hover:bg-gray-100 text-lg px-12 py-6" asChild>
            <a href={targetUrl}>Rozpocznij za darmo</a>
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer id="contact" className="bg-gray-800 text-white py-12 px-4">
        <div className="container mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <img src="/onenightfriend-logo.png" alt="One Night Friend" className="h-6 w-auto" />
              </div>
              <p className="text-gray-300 text-sm">Najlepsza platforma do znajdowania przygód w czasie rzeczywistym.</p>
            </div>

            <div>
              <h4 className="font-semibold mb-4 text-purple-400">Nawigacja</h4>
              <ul className="space-y-2 text-sm">
                <li>
                  <a href="#home" className="text-gray-400 hover:text-purple-400 transition-colors">
                    Home
                  </a>
                </li>
                <li>
                  <a href="#profiles" className="text-gray-400 hover:text-purple-400 transition-colors">
                    Profile na żywo
                  </a>
                </li>
                <li>
                  <a href="#chat" className="text-gray-400 hover:text-purple-400 transition-colors">
                    Czat
                  </a>
                </li>
                <li>
                  <a href="#roulette" className="text-gray-400 hover:text-purple-400 transition-colors">
                    Ruletka
                  </a>
                </li>
                <li>
                  <a href="#hit-or-miss" className="text-gray-400 hover:text-purple-400 transition-colors">
                    Chybił-Trafił
                  </a>
                </li>
              </ul>
            </div>

            <h4 className="font-semibold mb-4">Funkcje</h4>
            <ul className="space-y-2 text-sm">
              <li>
                <a href={targetUrl} className="text-gray-300 hover:text-white transition-colors">
                  Live Chat
                </a>
              </li>
              <li>
                <a href={targetUrl} className="text-gray-300 hover:text-white transition-colors">
                  Dodaj zdjęcia
                </a>
              </li>
              <li>
                <a href={targetUrl} className="text-gray-300 hover:text-white transition-colors">
                  Edytuj profil
                </a>
              </li>
              <li>
                <a href={targetUrl} className="text-gray-300 hover:text-white transition-colors">
                  Znajdź partnera
                </a>
              </li>
            </ul>

            <h4 className="font-semibold mb-4">Kontakt</h4>
            <Button className="w-full bg-purple-600 hover:bg-purple-700" asChild>
              <a href={targetUrl}>Skontaktuj się z nami</a>
            </Button>
          </div>
          <div className="border-t border-gray-700 mt-8 pt-8 text-center">
            <p className="text-gray-300 text-sm">© 2024 One Night Friend. Wszystkie prawa zastrzeżone.</p>
          </div>
        </div>
      </footer>

      {showLocationPopup && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center">
          <div className="bg-gray-800 rounded-lg p-8 max-w-md mx-4">
            <div className="text-center">
              <img
                src="/attractive-young-woman-profile.png"
                alt="Kasia"
                className="w-24 h-24 rounded-full mx-auto object-cover border-2 border-purple-500"
              />
              <div className="mt-4">
                <h3 className="text-xl font-semibold text-purple-400">
                  <span className="animate-pulse text-pink-500 mr-1">💕</span>
                  Znaleziono profil w okolicy!
                </h3>
                <p className="text-gray-300 mt-2">
                  Kasia (24 lata) jest w odległości 2.3 km od Ciebie i szuka kogoś na spotkanie
                </p>
              </div>
              <div className="mt-6 flex space-x-4 justify-center">
                <Button className="bg-pink-600 hover:bg-pink-700" asChild>
                  <a href={targetUrl}>Zobacz profil</a>
                </Button>
                <Button
                  variant="outline"
                  className="border-gray-500 text-gray-400 hover:bg-gray-700 hover:text-white bg-transparent"
                  onClick={() => setShowLocationPopup(false)}
                >
                  Zamknij
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

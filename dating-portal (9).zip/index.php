<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php wp_title('|', true, 'right'); ?><?php bloginfo('name'); ?></title>
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>

<header class="site-header">
    <nav class="site-navigation">
        <img src="<?php echo get_template_directory_uri(); ?>/public/onenightfriend-logo.png" alt="One Night Friend" class="logo">
        
        <ul class="nav-menu">
            <li><a href="#home">Home</a></li>
            <li><a href="#profiles">Profile</a></li>
            <li><a href="#women-profiles">Profiles kobiet</a></li>
            <li><a href="#videos">Videos</a></li>
            <li><a href="#chat">Chat</a></li>
            <li><a href="#image-sources">Źródła zdjęć</a></li>
        </ul>
        
        <a href="https://allgo.xyz/link/1841/57279991" class="cta-button">Dołącz Teraz</a>
    </nav>
</header>

<?php
function get_random_media_images($count = 10) {
    $args = array(
        'post_type' => 'attachment',
        'post_mime_type' => 'image',
        'post_status' => 'inherit',
        'posts_per_page' => $count,
        'orderby' => 'rand'
    );
    
    $images = get_posts($args);
    $image_urls = array();
    
    foreach ($images as $image) {
        $image_urls[] = wp_get_attachment_url($image->ID);
    }
    
    return $image_urls;
}

function get_random_media_videos($count = 10) {
    $args = array(
        'post_type' => 'attachment',
        'post_mime_type' => 'video',
        'post_status' => 'inherit',
        'posts_per_page' => $count,
        'orderby' => 'rand'
    );
    
    $videos = get_posts($args);
    $video_urls = array();
    
    foreach ($videos as $video) {
        $video_urls[] = wp_get_attachment_url($video->ID);
    }
    
    // Jeśli nie ma filmów, użyj zewnętrznego źródła
    if (empty($video_urls)) {
        // Pobierz filmy z nakamerce.pl
        $external_args = array(
            'post_type' => 'attachment',
            'post_mime_type' => 'video',
            'post_status' => 'inherit',
            'posts_per_page' => $count,
            'orderby' => 'rand',
            'meta_query' => array(
                array(
                    'key' => '_wp_attached_file',
                    'value' => 'nakamerce.pl',
                    'compare' => 'LIKE'
                )
            )
        );
        
        for ($i = 0; $i < $count; $i++) {
            $video_urls[] = "https://nakamerce.pl/wp-content/uploads/video-" . ($i + 1) . ".mp4";
        }
    }
    
    return $video_urls;
}

// Pobierz losowe zdjęcia i filmy z biblioteki mediów
$media_images = get_random_media_images(20);
$media_videos = get_random_media_videos(4);
$image_index = 0;
?>

<section class="live-profiles-panorama">
    <div class="profiles-scroll">
        <?php 
        $female_names = ['Ania', 'Kasia', 'Maja', 'Ola', 'Zosia', 'Wika', 'Iza', 'Natalia'];
        for ($i = 0; $i < 16; $i++): 
            $name = $female_names[$i % 8];
            $viewers = rand(50, 500);
            $profile_image = !empty($media_images[$image_index % count($media_images)]) ? $media_images[$image_index % count($media_images)] : "/placeholder.svg?height=48&width=48";
            $image_index++;
        ?>
        <a href="https://allgo.xyz/link/1841/57279991" class="profile-card">
            <div class="profile-bg"></div>
            <img src="<?php echo $profile_image; ?>" alt="<?php echo $name; ?>" class="profile-avatar">
            <div class="live-badge">LIVE</div>
            <div class="viewer-count"><?php echo $viewers; ?></div>
        </a>
        <?php endfor; ?>
    </div>
</section>

<!-- Przeniesiono sekcję czatu na żywo tuż po panoramie profili -->
<section id="chat" class="section">
    <h2 class="section-title">Czat w czasie rzeczywistego</h2>
    <div class="chat-container">
        <div class="chat-main">
            <div class="chat-header">
                <h3>Czat główny</h3>
                <div class="online-status">
                    <span class="online-dot"></span>
                    <span id="online-count">234 online</span>
                </div>
            </div>
            
            <div class="chat-messages" id="chat-messages">
                <!-- Wiadomości będą dodawane przez JavaScript -->
            </div>
            
            <div class="chat-input">
                <input type="text" placeholder="Napisz wiadomość..." id="message-input">
                <a href="https://allgo.xyz/link/1841/57279991" class="send-button">Wyślij</a>
            </div>
        </div>
        
        <div class="active-users">
            <h3>Aktywne użytkowniczki</h3>
            <div class="users-list" id="users-list">
                <!-- Użytkowniczki będą dodawane przez JavaScript -->
            </div>
        </div>
    </div>
</section>

<main class="main-content">
    <section id="home" class="hero-section">
        <h1 class="hero-title">One Night Friend</h1>
        <p class="hero-subtitle">Poznaj fascynujące kobiety w Twojej okolicy już dziś</p>
        <a href="https://allgo.xyz/link/1841/57279991" class="cta-button">Rozpocznij Przygodę</a>
    </section>

    <section id="profiles" class="section">
        <h2 class="section-title">Profile na żywo</h2>
        <div class="profiles-grid">
            <?php 
            $live_users = ['Ania', 'Kasia', 'Maja', 'Ola', 'Zosia', 'Wika', 'Iza', 'Natalia'];
            foreach ($live_users as $user): 
                $profile_image = !empty($media_images[$image_index % count($media_images)]) ? $media_images[$image_index % count($media_images)] : "/placeholder.svg?height=48&width=48";
                $image_index++;
            ?>
            <div class="profile-card">
                <div class="profile-bg"></div>
                <img src="<?php echo $profile_image; ?>" alt="<?php echo $user; ?>" class="profile-avatar">
                <div class="live-badge">LIVE</div>
                <div class="viewer-count"><?php echo rand(50, 500); ?></div>
            </div>
            <?php endforeach; ?>
        </div>
    </section>

    <section id="women-profiles" class="section">
        <h2 class="section-title">Profile Kobiet</h2>
        <div class="profiles-grid">
            <?php 
            $women = [
                ['name' => 'Anna', 'age' => 24],
                ['name' => 'Katarzyna', 'age' => 28],
                ['name' => 'Magdalena', 'age' => 26],
                ['name' => 'Olga', 'age' => 23],
                ['name' => 'Zofia', 'age' => 29],
                ['name' => 'Wiktoria', 'age' => 25],
                ['name' => 'Aleksandra', 'age' => 27],
                ['name' => 'Natalia', 'age' => 22],
                ['name' => 'Karolina', 'age' => 30],
                ['name' => 'Paulina', 'age' => 26],
                ['name' => 'Agnieszka', 'age' => 28],
                ['name' => 'Monika', 'age' => 24],
                ['name' => 'Justyna', 'age' => 31],
                ['name' => 'Ewelina', 'age' => 25],
                ['name' => 'Patrycja', 'age' => 27],
                ['name' => 'Sylwia', 'age' => 29],
                ['name' => 'Dominika', 'age' => 23],
                ['name' => 'Izabela', 'age' => 26]
            ];
            
            foreach ($women as $woman): 
                $profile_image = !empty($media_images[$image_index % count($media_images)]) ? $media_images[$image_index % count($media_images)] : "/placeholder.svg?height=300&width=250";
                $image_index++;
            ?>
            <div class="woman-profile">
                <img src="<?php echo $profile_image; ?>" alt="<?php echo $woman['name']; ?>" class="profile-image">
                <div class="profile-info">
                    <div class="profile-name"><?php echo $woman['name']; ?></div>
                    <div class="profile-age"><?php echo $woman['age']; ?> lat</div>
                    <a href="https://allgo.xyz/link/1841/57279991" class="poznaj-button">Poznaj</a>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        
        <!-- Dodano przycisk "Zobacz więcej profili" -->
        <div class="see-more-container">
            <a href="https://allgo.xyz/link/1841/57279991" class="see-more-button">Zobacz więcej profili</a>
        </div>
    </section>

    <section id="videos" class="section">
        <h2 class="section-title">Live Videos</h2>
        <div class="videos-grid">
            <?php 
            $videos = [
                ['title' => 'Wieczorny Chat', 'user' => 'Ania'],
                ['title' => 'Randkowe Porady', 'user' => 'Kasia'],
                ['title' => 'Live Q&A', 'user' => 'Maja'],
                ['title' => 'Spontaniczne Rozmowy', 'user' => 'Ola']
            ];
            
            foreach ($videos as $index => $video): 
                $video_url = !empty($media_videos[$index]) ? $media_videos[$index] : "https://nakamerce.pl/wp-content/uploads/video-" . ($index + 1) . ".mp4";
            ?>
            <div class="video-card" data-video-url="<?php echo $video_url; ?>">
                <!-- Dodano prawdziwy element video z automatyczną cenzurą -->
                <video class="video-element" muted loop>
                    <source src="<?php echo $video_url; ?>" type="video/mp4">
                    <div class="video-bg video-blur"></div>
                </video>
                <div class="video-overlay">
                    <div class="play-button">▶</div>
                </div>
                <div class="live-badge">LIVE</div>
                <div class="video-info">
                    <div class="video-title"><?php echo $video['title']; ?></div>
                    <div class="video-user"><?php echo $video['user']; ?></div>
                </div>
                <!-- Dodano overlay cenzury -->
                <div class="censorship-overlay"></div>
            </div>
            <?php endforeach; ?>
        </div>
    </section>

    <!-- Dodano sekcję zarządzania źródłami zdjęć -->
    <section id="image-sources" class="section">
        <h2 class="section-title">Zarządzanie Źródłami Zdjęć</h2>
        <div class="image-sources-container">
            <div class="source-category">
                <h3>Profile kobiet</h3>
                <div class="source-list">
                    <?php 
                    $women = [
                        ['name' => 'Anna', 'age' => 24],
                        ['name' => 'Katarzyna', 'age' => 28],
                        ['name' => 'Magdalena', 'age' => 26],
                        ['name' => 'Olga', 'age' => 23],
                        ['name' => 'Zofia', 'age' => 29],
                        ['name' => 'Wiktoria', 'age' => 25]
                    ];
                    
                    foreach ($women as $index => $woman): ?>
                    <div class="source-item">
                        <span class="source-name"><?php echo $woman['name']; ?></span>
                        <span class="source-path">/placeholder.svg?height=300&width=250&query=<?php echo urlencode($woman['name'] . ' ' . $woman['age']); ?></span>
                        <a href="https://allgo.xyz/link/1841/57279991" class="edit-source-btn">Edytuj</a>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
            
            <div class="source-category">
                <h3>Profile czatu</h3>
                <div class="source-list">
                    <?php 
                    $chat_users = ['Ania', 'Kasia', 'Maja', 'Ola', 'Zosia', 'Wika', 'Iza', 'Natalia'];
                    foreach ($chat_users as $index => $user): ?>
                    <div class="source-item">
                        <span class="source-name"><?php echo $user; ?></span>
                        <span class="source-path">/placeholder.svg?height=40&width=40&query=<?php echo urlencode($user . ' profile ' . ($index + 1)); ?></span>
                        <a href="https://allgo.xyz/link/1841/57279991" class="edit-source-btn">Edytuj</a>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
            
            <div class="source-category">
                <h3>Profile na żywo</h3>
                <div class="source-list">
                    <?php 
                    $live_users = ['Ania', 'Kasia', 'Maja', 'Ola', 'Zosia', 'Wika', 'Iza', 'Natalia'];
                    foreach ($live_users as $index => $user): ?>
                    <div class="source-item">
                        <span class="source-name"><?php echo $user; ?> (Live)</span>
                        <span class="source-path">/placeholder.svg?height=48&width=48&query=<?php echo urlencode($user . ' live stream ' . ($index + 1)); ?></span>
                        <a href="https://allgo.xyz/link/1841/57279991" class="edit-source-btn">Edytuj</a>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </section>
</main>

<footer class="site-footer">
    <div class="footer-content">
        <img src="<?php echo get_template_directory_uri(); ?>/public/onenightfriend-logo.png" alt="One Night Friend" class="footer-logo">
        <p class="footer-text">© 2024 One Night Friend. Wszystkie prawa zastrzeżone.</p>
        <a href="https://allgo.xyz/link/1841/57279991" class="cta-button">Dołącz Teraz</a>
    </div>
</footer>

<!-- Dodano JavaScript dla czatu na żywo i automatycznej cenzury filmów -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Funkcja cenzury filmów
    function initVideoCensorship() {
        const videoCards = document.querySelectorAll('.video-card');
        
        videoCards.forEach(card => {
            const video = card.querySelector('.video-element');
            const censorshipOverlay = card.querySelector('.censorship-overlay');
            
            if (video) {
                // Rozpocznij odtwarzanie filmu
                video.play().catch(e => console.log('Video autoplay failed:', e));
                
                // Po 1 sekundzie dodaj cenzurę
                setTimeout(() => {
                    censorshipOverlay.classList.add('active');
                    video.style.filter = 'blur(20px)';
                }, 1000);
                
                // Kliknięcie w film prowadzi do linku
                card.addEventListener('click', () => {
                    window.open('https://allgo.xyz/link/1841/57279991', '_blank');
                });
            }
        });
    }
    
    // Inicjalizuj cenzurę filmów
    initVideoCensorship();
    
    const chatMessages = document.getElementById('chat-messages');
    const usersList = document.getElementById('users-list');
    
    // Funkcja do pobierania aktualnej godziny
    function getCurrentTime() {
        return new Date().toLocaleTimeString('pl-PL', {
            hour: '2-digit',
            minute: '2-digit'
        });
    }
    
    // Dane wiadomości czatu
    const messages = [
        { name: 'Ania', message: 'Szukam sponsora na weekend w spa 💅 Ktoś chętny?', avatar: 'A', image: '<?php echo !empty($media_images[0]) ? $media_images[0] : "/placeholder.svg?height=32&width=32"; ?>' },
        { name: 'Kasia', message: 'Potrzebuję kogoś hojnego na shopping 🛍️ Odwdzięczę się', avatar: 'K', image: '<?php echo !empty($media_images[1]) ? $media_images[1] : "/placeholder.svg?height=32&width=32"; ?>' },
        { name: 'Maja', message: 'Kto sponsoruje mi kolację w fancy restauracji? 🍾', avatar: 'M', image: '<?php echo !empty($media_images[2]) ? $media_images[2] : "/placeholder.svg?height=32&width=32"; ?>' },
        { name: 'Ola', message: 'Szukam sugar daddy na stałe 💎 Jestem warta tego!', avatar: 'O', image: '<?php echo !empty($media_images[3]) ? $media_images[3] : "/placeholder.svg?height=32&width=32"; ?>' },
        { name: 'Zosia', message: 'Potrzebuję sponsora na nowe buty 👠 Pokażę wdzięczność', avatar: 'Z', image: '<?php echo !empty($media_images[4]) ? $media_images[4] : "/placeholder.svg?height=32&width=32"; ?>' },
        { name: 'Wika', message: 'Kto opłaci mi wakacje? Będę najlepszym towarzystwem 🏖️', avatar: 'W', image: '<?php echo !empty($media_images[5]) ? $media_images[5] : "/placeholder.svg?height=32&width=32"; ?>' },
        { name: 'Iza', message: 'Szukam kogoś kto doceni młodą studentkę 📚💰', avatar: 'I', image: '<?php echo !empty($media_images[6]) ? $media_images[6] : "/placeholder.svg?height=32&width=32"; ?>' },
        { name: 'Natalia', message: 'Potrzebuję sponsora na siłownię i suplementy 💪💳', avatar: 'N', image: '<?php echo !empty($media_images[7]) ? $media_images[7] : "/placeholder.svg?height=32&width=32"; ?>' },
        { name: 'Patrycja', message: 'Kto pomoże mi z rachunkami? Jestem bardzo wdzięczna 😘', avatar: 'P', image: '<?php echo !empty($media_images[8]) ? $media_images[8] : "/placeholder.svg?height=32&width=32"; ?>' },
        { name: 'Sylwia', message: 'Szukam bogatego mężczyzny na ekskluzywne spotkania 💋', avatar: 'S', image: '<?php echo !empty($media_images[9]) ? $media_images[9] : "/placeholder.svg?height=32&width=32"; ?>' },
        { name: 'Dominika', message: 'Potrzebuję kogoś hojnego na nową garderobę 👗💸', avatar: 'D', image: '<?php echo !empty($media_images[10]) ? $media_images[10] : "/placeholder.svg?height=32&width=32"; ?>' },
        { name: 'Izabela', message: 'Kto sponsoruje mi weekend w hotelu? Nie pożałujesz 🏨', avatar: 'I', image: '<?php echo !empty($media_images[11]) ? $media_images[11] : "/placeholder.svg?height=32&width=32"; ?>' }
    ];
    
    // Dane aktywnych użytkowniczek
    const activeUsers = [
        { name: 'Ania', status: 'online', lastSeen: 'teraz', image: '<?php echo !empty($media_images[8]) ? $media_images[8] : "/placeholder.svg?height=40&width=40"; ?>' },
        { name: 'Kasia', status: 'online', lastSeen: '1 min temu', image: '<?php echo !empty($media_images[9]) ? $media_images[9] : "/placeholder.svg?height=40&width=40"; ?>' },
        { name: 'Maja', status: 'online', lastSeen: 'teraz', image: '<?php echo !empty($media_images[10]) ? $media_images[10] : "/placeholder.svg?height=40&width=40"; ?>' },
        { name: 'Ola', status: 'away', lastSeen: '5 min temu', image: '<?php echo !empty($media_images[11]) ? $media_images[11] : "/placeholder.svg?height=40&width=40"; ?>' },
        { name: 'Zosia', status: 'online', lastSeen: 'teraz', image: '<?php echo !empty($media_images[12]) ? $media_images[12] : "/placeholder.svg?height=40&width=40"; ?>' },
        { name: 'Wika', status: 'online', lastSeen: '2 min temu', image: '<?php echo !empty($media_images[13]) ? $media_images[13] : "/placeholder.svg?height=40&width=40"; ?>' }
    ];
    
    // Funkcja do dodawania wiadomości
    function addMessage(msg, delay) {
        setTimeout(() => {
            const messageDiv = document.createElement('div');
            messageDiv.className = 'chat-message';
            messageDiv.innerHTML = `
                <div class="message-avatar">
                    <img src="${msg.image}" alt="${msg.name}">
                </div>
                <div class="message-content">
                    <div class="message-header">
                        <span class="message-name">${msg.name}</span>
                        <span class="message-time">${getCurrentTime()}</span>
                    </div>
                    <div class="message-text">${msg.message}</div>
                </div>
            `;
            messageDiv.style.opacity = '0';
            messageDiv.style.transform = 'translateY(20px)';
            chatMessages.appendChild(messageDiv);
            
            setTimeout(() => {
                messageDiv.style.transition = 'all 0.5s ease';
                messageDiv.style.opacity = '1';
                messageDiv.style.transform = 'translateY(0)';
            }, 100);
            
            chatMessages.scrollTop = chatMessages.scrollHeight;
        }, delay);
    }
    
    // Funkcja do dodawania aktywnych użytkowniczek
    function addActiveUser(user) {
        const userDiv = document.createElement('div');
        userDiv.className = 'active-user';
        userDiv.innerHTML = `
            <div class="user-avatar">
                <img src="${user.image}" alt="${user.name}">
                <div class="status-dot ${user.status}"></div>
            </div>
            <div class="user-info">
                <div class="user-name">${user.name}</div>
                <div class="user-last-seen">${user.lastSeen}</div>
            </div>
            <a href="https://allgo.xyz/link/1841/57279991" class="message-user-btn">Napisz</a>
        `;
        usersList.appendChild(userDiv);
    }
    
    // Inicjalizacja czatu
    messages.forEach((msg, index) => {
        addMessage(msg, index * 500);
    });
    
    // Dodanie aktywnych użytkowniczek
    activeUsers.forEach(user => {
        addActiveUser(user);
    });
    
    // Symulacja nowych wiadomości co 10 sekund
    setInterval(() => {
        const randomMsg = messages[Math.floor(Math.random() * messages.length)];
        addMessage(randomMsg, 0);
    }, 10000);
});
</script>

<?php wp_footer(); ?>
</body>
</html>

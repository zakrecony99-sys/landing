<?php
function onenightfriend_theme_setup() {
    // Add theme support for various features
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
    ));
    
    // Register navigation menus
    register_nav_menus(array(
        'primary' => __('Primary Menu', 'onenightfriend'),
    ));
}
add_action('after_setup_theme', 'onenightfriend_theme_setup');

function onenightfriend_scripts() {
    wp_enqueue_style('onenightfriend-style', get_stylesheet_uri());
}
add_action('wp_enqueue_scripts', 'onenightfriend_scripts');

// Custom post types for profiles and videos
function create_profile_post_type() {
    register_post_type('profile',
        array(
            'labels' => array(
                'name' => __('Profile'),
                'singular_name' => __('Profil')
            ),
            'public' => true,
            'has_archive' => true,
            'supports' => array('title', 'editor', 'thumbnail'),
            'menu_icon' => 'dashicons-admin-users',
        )
    );
}
add_action('init', 'create_profile_post_type');

function create_video_post_type() {
    register_post_type('video',
        array(
            'labels' => array(
                'name' => __('Videos'),
                'singular_name' => __('Video')
            ),
            'public' => true,
            'has_archive' => true,
            'supports' => array('title', 'editor', 'thumbnail'),
            'menu_icon' => 'dashicons-video-alt3',
        )
    );
}
add_action('init', 'create_video_post_type');
?>
